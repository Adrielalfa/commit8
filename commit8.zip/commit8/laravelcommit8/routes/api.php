<?php

use App\Http\Controllers\Api\CobaController;
use App\Http\Controllers\Api\GroupController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

@@ -14,6 +16,9 @@
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('', [CobaController::class, 'index']);
Route::resources([
    'friends' => CobaController::class,
    'groups' => GroupsController::class,
]);
